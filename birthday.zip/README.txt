SANIA'S BIRTHDAY WEBSITE 🎀

Files:
- index.html
- assets/memory1.jpg
- assets/memory2.jpg
- assets/memory3.jpg
- assets/memory4.jpg
- assets/sania.jpg

HOW TO USE:
1. Keep the folder structure exactly as it is.
2. Double-click index.html to preview it in a browser.
3. To share it as a link, upload the whole folder to a static hosting service (for example GitHub Pages, Netlify, or Vercel).

PHOTO ORDER:
memory1 = uploaded photo 1
memory2 = uploaded photo 2
memory3 = uploaded photo 3
memory4 = uploaded photo 5
sania = uploaded photo 4

The website is already wired up in the requested sequence:
black screen → candle → birthday/confetti → memories → gift → Sania photo → forever question → escaping NO → YES result.

NOTE:
The Google Fonts are loaded from the internet. The website still works without them, but the typography will fall back to system fonts if offline.
